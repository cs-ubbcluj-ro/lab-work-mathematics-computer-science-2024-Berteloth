#include <iostream>
using namespace std;

int main() {
    int k;
    int i;
    int j;
    int isPrime;
    cin >> k;

    for (i = 2; i < k; i = i + 1) {
        isPrime = 1;

        for (j = 2; j < i; j = j + 1) {
            if (i % j == 0) {
                isPrime = 0;
                break;
            }
        }

        if (isPrime == 1) {
            cout << i;
        }
    }

    cout << endl;
}
