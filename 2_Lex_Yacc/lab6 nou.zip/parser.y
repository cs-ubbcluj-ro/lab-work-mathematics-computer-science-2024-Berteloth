%{
#include <stdio.h>
#include <stdlib.h>

extern int yylex();
extern FILE* yyin;
void yyerror(const char *s);
extern int yyparse();
extern int yylineno;
extern int yydebug;

#define YYDEBUG 1


void log_production(char *prod_number);


%}
%token INCLUDE
%token IDENTIFIER CONSTANT_T FOR BREAK ENDL
%token PLUS MINUS MUL DIV MOD CIN COUT IF ELSE WHILE INT MAIN RETURN SEMICOLON COMMA
%token LBRACE RBRACE LPAREN RPAREN GT LT GTE LTE EQ NEQ
%token BOOL CHAR STRING DOUBLE
%token RSHIFT LSHIFT
%token STRING_LITERAL
%left PLUS MINUS
%left MUL DIV MOD
%nonassoc LT LTE GT GTE EQ NEQ ELSE
%token USING NAMESPACE STD
%token ASSIGN

%start Program

%%

Program
    : INCLUDE LT IDENTIFIER GT using_declaration INT MAIN LPAREN RPAREN LBRACE statement_list RBRACE
        { printf("Program syntactic correct\n"); log_production("PROGRAM STARTS"); }
    ;
    
using_declaration
    : USING NAMESPACE STD SEMICOLON
        { log_production("using_declaration"); }
    ;

statement_list
    : /* empty */
        { log_production("statement_list"); }
    | statement_list statement
        { log_production("statement_list -> statement"); }
    ;

statement
    : declare
        { log_production("statement -> declare"); }
    | assign_statement
        { log_production("statement -> assign_statement");}
    | expr
        { log_production("statement -> expr"); }
    | input_output_statement
        { log_production("statement -> input_output_statement"); }
    | compound_statement
        { log_production("statement -> compound_statement"); }
    | if_statement
        { log_production("statement -> if_statement"); }
    | while_statement
        { log_production("statement -> while_statement"); }
    | for_statement
        { log_production("statement -> for_statement"); }
    | return_statement
        { log_production("statement -> return_statement"); }
    | break
        { log_production("statement -> break"); }
    ;

declare
    : type IDENTIFIER SEMICOLON
        { log_production("declare"); }
    ;
    
assign_statement
    : IDENTIFIER ASSIGN expr SEMICOLON
        { printf("Assignment: %s = (expr)\n", $1); log_production("assign_statement"); }
    ;
    
type
    : INT
        { log_production("type INT"); }
    | DOUBLE
        { log_production("type DOUBLE"); }
    | CHAR
        { log_production("type CHAR"); }
    | BOOL
        { log_production("type BOOL"); }
    ;

expr
    : 
    term tail1
        { log_production("expr"); }
    ;
    
tail1
    : PLUS term tail1
        { log_production("tail1 PLUS"); }
    | MINUS term tail1
        { log_production("tail1 MINUS"); }
    | /* empty */
        { log_production("tail1 EMPTY"); }
    ;


    
term
    : factor tail2
        { log_production("term"); }
    ;

tail2
    : MUL factor tail2
        { log_production("tail2 MUL"); }
    | DIV factor tail2
        { log_production("tail2 DIV"); }
    | MOD factor tail2
        { log_production("tail2 MOD"); }
    | /* empty */
        { log_production("tail2 empty"); }
    ;

factor
    : CONSTANT_T
        { log_production("factor -> CONSTANT_T"); }
    | IDENTIFIER
        { log_production("factor -> IDENTIFIER"); }
    | LPAREN expr RPAREN
        { log_production("factor -> LPAREN expr RPAREN"); }
    ;

input_output_statement
    : CIN RSHIFT IDENTIFIER SEMICOLON
        { log_production("input_output_statement -> input"); }
    | COUT LSHIFT IDENTIFIER SEMICOLON
        { log_production("input_output_statement -> output"); }
    ;

compound_statement
    : LBRACE statement_list RBRACE
        { log_production("compound_statement"); }
    ;

condition
    : expr
        { log_production("condition -> expr"); }
    | expr relation expr
        { log_production("condition -> expr rel expr"); }
    ;

relation
    : LT
        { log_production("relation -> LT"); }
    | LTE
        { log_production("relation -> LTE"); }
    | GT
        { log_production("relation -> GT"); }
    | GTE
        { log_production("relation -> GTE"); }
    | EQ
        { log_production("relation -> EQ"); }
    | NEQ
        { log_production("relation -> NEQ"); }
    ;

if_statement

    : IF LPAREN condition RPAREN statement %prec ELSE

        { log_production("if_statement -> if"); }

    | IF LPAREN condition RPAREN statement ELSE statement

        { log_production("if_statement -> if_else"); }

    ;
    
expr_statement
    : expr SEMICOLON
        { log_production("expr_statement"); }
    ;

while_statement
    : WHILE LPAREN condition RPAREN statement
        { log_production("while_statement"); }
    ;

for_statement
    : FOR LPAREN expr_statement expr_statement expr RPAREN statement
        { log_production("for_statement"); }
    ;

return_statement
    : RETURN CONSTANT_T SEMICOLON
        { log_production("return_statement"); }
    ;


break
    : BREAK SEMICOLON
        { log_production("break"); }
    ;

%%


void log_production(char* prod_number) {
    printf("Production used: %s\n", prod_number);
}

void yyerror(const char *s) {
    printf("Error: %s\n", s);
	printf("Erorr  %d", yylineno);
    printf("Current token: %d\n", yylex()); // Print the token where the error occurred
}

int main(int argc, char** argv) {
    yydebug = 0; 

    if (argc != 2) {
        printf("Usage: %s input file\n", argv[0]);
        return 1;
    }	
	
    yyin = fopen(argv[1], "r");
    if (!yyin) {
        perror("Error opening file");
        return 1;
    }
	//printf("parsing %d", yyparse());
    if (yyparse() == 0) {
        printf("Parsing completed successfully.\n");
    } else {
        printf("Parsing failed.\n");
    }
	
    return 0;
}
